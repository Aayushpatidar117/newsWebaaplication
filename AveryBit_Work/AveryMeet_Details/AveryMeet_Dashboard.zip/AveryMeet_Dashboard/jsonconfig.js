{
    "compilerOptions": {
     "jsx": "react-jsx",
     "module": "esnext",
     "target": "es6",
     "moduleResolution": "node",
     "allowSyntheticDefaultImports": true
    },
    "exclude": ["node_modules"]
    }