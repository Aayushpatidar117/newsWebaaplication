import { useSelector } from "react-redux";
import Home from "../main/Home";
import MyConversation from "../main/MyConversation";
import AllConversation from "../main/AllConversation";
import SharedWithMe from "../main/SharedWithMe";
import Trash from "../main/Trash";

const CenterView = () => { 
  const selectedNavItem = useSelector((state) => state.popup.selectedNavItem);

  switch (selectedNavItem) { 
    case "Home":
      return <Home />;
    case "My Conversation":
      return <MyConversation />;
    case "All Conversation":
      return <AllConversation />;
    case "Shared with Me":
      return <SharedWithMe />;
    case "Trash":
      return <Trash />;
    default:
      return <Home />;
  }
};

export default CenterView;
